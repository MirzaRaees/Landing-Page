import { Link, NavLink } from 'react-router-dom'
import './index.scss'
import LogoS from '../../assets/images/logo-s.png'
import Logo_sub from '../../assets/images/logo_sub.png'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faEnvelope, faHome, faPhone, faUser } from '@fortawesome/free-solid-svg-icons'
import { faLinkedin, faSkype, faYoutube } from '@fortawesome/free-brands-svg-icons'
const Sidebar = () => {

return (

    <div className='nav-bar'>
        <Link className='logo' to='/' >
        <img className='img' src={LogoS} alt='logo' />
        <img className='img' src={Logo_sub} alt='subtitle'/>
        </Link>

        <nav>
            <NavLink exact="true" activeclassname="active" className='home-link' to='/' >
                <FontAwesomeIcon icon={faHome} color='#fff' />
            </NavLink>

            <NavLink exact="true" activeclassname="active" className='contact-link' to='/contact' >
                <FontAwesomeIcon icon={faEnvelope} color='#fff' />
            </NavLink>

            <NavLink exact="true" activeclassname="active" className="about-link" to='/about' >
                <FontAwesomeIcon icon={faUser} color='#fff' />
            </NavLink>
        </nav>

        <ul>
            <li>
                <a 
                target='_blank'
                rel='norefrrer'
                href='#'
                >
                <FontAwesomeIcon icon={faYoutube} color='#fff' /> 

                </a>
            </li>
            <li>
                <a 
                target='_blank'
                rel='norefrrer'
                href='#'
                >
                <FontAwesomeIcon icon={faSkype} color='#fff' /> 

                </a>
            </li>
            <li>
                <a 
                target='_blank'
                rel='norefrrer'
                href='#'
                >
                <FontAwesomeIcon icon={faLinkedin} color='#fff' /> 

                </a>
            </li>
        </ul>
    </div>

)}

export default Sidebar