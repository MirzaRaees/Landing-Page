import { Outlet } from 'react-router-dom';
import Sidebar from '../Sidebar';
import './index.scss';

const Layout = () => {
    return ( <div className='app'>
    <Sidebar />
    <div className='page'>
        
        <Outlet />
        <span className='tags '>
            Mirza
            <br />
            <span className='tags-bottom'>Raees</span>
        </span>
    </div>
    </div> )
}

export default Layout