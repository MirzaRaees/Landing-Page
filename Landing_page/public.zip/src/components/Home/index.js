import LogoTitle from '/react-project/landing-page/src/assets/images/logo-s.png';
import ReactLogo from '/react-project/landing-page/src/assets/images/logo-react.png'
import './index.scss';
import Loader from 'react-loaders';
import { Link } from 'react-router-dom';
import AnimatedLetters  from '../AnimatedLetters';
import { useEffect, useState } from 'react';


const Home = () => {

        const [letterClass, setLetterClass] = useState('text-animate');
        const [imgClass, setImgClass] = useState('r');
        const [logoClass, setLogoClass] = useState('react');
        const nameArray = ['a', 'e', 'e', 's'];
        const jobArray = ['R', 'e', 'a', 'c', 't', '/', 'W', 'o', 'r','d','p' ,'r', 'e', 's', 's', ' ', 'D', 'e', 'v', 'e', 'l', 'o', 'p', 'e', 'r'] 


        useEffect(() => {

          setImgClass('r_2');
          setLogoClass('rotate');
               setTimeout(() => {
              setLetterClass('text-animate-hover')
          }
           ,4000 
          ) } 
          ,[] 
         )  ;

         



    return(
      <>
                  <Loader type="line-scale-pulse-out" />

        <div className="container home-page">
            <div className="text-zone">
                <h1>
                 <span className={` ${letterClass}   _11`}> H  </span>
                 <span className={` ${letterClass} _12`}> i,  </span>

                    <br />
                    <span className={` ${letterClass} _13`}> I  </span>
                    <span className={` ${letterClass} _14`}> 'm  </span>
                     <img src={LogoTitle} className={imgClass} alt="Title" />


                <AnimatedLetters letterClass={letterClass}
                  strArray={nameArray}
                  idx={15}
                />
                    
                </h1>
                 <h2 className='sub-title'><AnimatedLetters letterClass={letterClass}
                  strArray={jobArray}
                  idx={16}
                /></h2>
                  <Link to="/contact" className="flat-button" >Contact Me</Link>
            </div>

            <img src={ReactLogo} className={logoClass} alt='' />
            


        </div>
        </>
    )
}

export default Home